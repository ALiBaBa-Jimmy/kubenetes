#!/usr/bin/env bash

# Exit on error. Append "|| true" if you expect an error.
set -o errexit
# Exit on error inside any functions or subshells.
set -o errtrace
# Do not allow use of undefined vars. Use ${VAR:-} to use an undefined VAR
set -o nounset
# Catch an error in command pipes. e.g. mysqldump fails (but gzip succeeds)
# in `mysqldump |gzip`
set -o pipefail
if [[ "${DEBUG:-}" = "true" ]]; then
# Turn on traces, useful while debugging but commented out by default
  set -o xtrace
fi

_MY_SCRIPT="${BASH_SOURCE[0]}"
_TEST_DIR=$(cd "$(dirname "$_MY_SCRIPT")" && pwd)
export PATH=${_TEST_DIR}/bin:$PATH
source ${_TEST_DIR}/lib/_k8s.sh

_PROJECT_DIR=$(cd "$(dirname "$_TEST_DIR")" && pwd)
_CHART_DIR=${_PROJECT_DIR}/charts

function _run () {
  local attempts=2
  echo Running: "$@"
  until "$@"; do
    ((attempts--)) || return 1
    sleep 5
  done
}

kubectl cluster-info
cd $_CHART_DIR

_DEFAULT_CASES="*"
: "${CASES:=$_DEFAULT_CASES}"
_CASES=$(ls ${_TEST_DIR}/cases/${CASES})
for _CASE in $_CASES; do
  echo Running test case: $_CASE
  source $_CASE
  run_test_case
  if [[ "${SKIP_CLEANUP:-false}" = "false" ]]; then
    echo Cleaning up test case: $_CASE
    cleanup_test_case
  fi
done
